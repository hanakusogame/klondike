function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */


        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (!revert) {
            this.clear();
            return;
          }

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.cancel(true);
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */


        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];

              if (!action.initialized) {
                this._initAction(action);
              }

              var keys = Object.keys(action.goal);

              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }

              if (action.type === ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (revert) {
            var keys = Object.keys(this._initialProp);

            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j]; // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)

                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Button = void 0;

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 200;
          }

          if (h === void 0) {
            h = 100;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          }; // this.pushEvent = () => {};


          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: "monospace",
              size: 48
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 48,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.onPointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.onPointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Card = void 0;

      var tl = require("@akashic-extension/akashic-timeline"); //カードクラス


      var Card =
      /** @class */
      function (_super) {
        __extends(Card, _super);

        function Card(maingame, mark, num, x, y) {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            x: x,
            y: y,
            width: 120,
            height: 180,
            touchable: true
          }) || this;
          var timeline = new tl.Timeline(scene);
          _this.isOpen = false;
          _this.num = num;
          _this.mark = mark;
          _this.isBfuda = false;
          _this.isKfuda = false;
          var sprite = new g.FrameSprite({
            scene: scene,
            src: scene.asset.getImageById("card"),
            x: 120 / 2,
            y: 180 / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            width: 120,
            height: 180,
            frames: [0, 1, 2],
            frameNumber: 1,
            parent: _this
          });
          var base = new g.E({
            scene: scene,
            parent: sprite
          });
          base.hide();
          new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("mark"),
            x: 2,
            y: 2,
            srcX: 40 * mark,
            width: 40,
            parent: base
          });
          new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("number2"),
            x: 40,
            y: 2,
            srcX: 40 * (num - 1),
            srcY: 50 * Math.floor(mark / 2),
            width: 40,
            height: 40,
            parent: base
          });

          if (num <= 10) {
            new g.Sprite({
              scene: scene,
              src: scene.asset.getImageById("mark2"),
              x: 10,
              y: 60,
              srcX: 100 * mark,
              width: 100,
              height: 100,
              parent: base
            });
          } else {
            new g.Sprite({
              scene: scene,
              src: scene.asset.getImageById("mark3"),
              x: 0,
              y: 45,
              srcX: 120 * (num - 11),
              width: 120,
              height: 120,
              parent: base
            });
          }

          _this.open = function (isAnime) {
            if (_this.isOpen) return;
            sprite.frameNumber = 0;
            base.show();
            _this.isOpen = true;

            if (isAnime) {
              timeline.create(sprite).scaleTo(0, 1, 200).scaleTo(1, 1, 200);
            }
          };

          _this.close = function () {
            sprite.frameNumber = 1;
            base.hide();
            _this.isOpen = false;
          }; //カードをつかむ


          var bkCards = null;
          var bkArea = null;
          var bkP = {
            x: 0,
            y: 0
          };

          _this.onPointDown.add(function (ev) {
            if (Card.tapCard) return;
            Card.tapCard = _this;
            bkCards = null;
            if (!scene.isStart) return;
            if (!_this.isOpen) return; //ダブルクリックで自動移動

            if (Card.doubleCard === _this) {
              maingame.autoMoves();
              bkCards = null;
              Card.doubleCard = null;
              maingame.clear();
              return;
            }

            if (Card.cntAnimeCards) return; //場札

            maingame.bHitAreas.forEach(function (a, i) {
              if (g.Collision.intersectAreas(_this, a)) {
                bkArea = maingame.bAreas[i];
                bkCards = bkArea.getCardsKeep(_this);
              }
            }); //組札

            maingame.kHitAreas.forEach(function (a, i) {
              if (g.Collision.intersectAreas(_this, a)) {
                bkArea = maingame.kAreas[i];
                bkCards = bkArea.cards.slice(-1);
              }
            }); //手札

            if (g.Collision.intersectAreas(_this, maingame.tHitArea)) {
              bkArea = maingame.tArea;
              bkCards = bkArea.cards.slice(-1);
            }

            if (!bkCards) return;
            Card.doubleCard = _this;
            scene.setTimeout(function () {
              Card.doubleCard = null;
            }, 500);
            bkP = {
              x: bkCards[0].x,
              y: bkCards[0].y
            };
            bkCards.forEach(function (c) {
              c.parent.append(c); //最前面へ
            });
          }); //カードを移動する


          _this.onPointMove.add(function (ev) {
            if (Card.tapCard !== _this) return;
            if (!scene.isStart) return;
            if (Card.cntAnimeCards) return;
            if (!bkCards) return;
            bkCards.forEach(function (c) {
              c.x += ev.prevDelta.x;
              c.y += ev.prevDelta.y;
              c.modified();
            });
          }); //カードを重ねる


          _this.onPointUp.add(function (ev) {
            if (Card.tapCard !== _this) return;
            Card.tapCard = null;
            if (!scene.isStart) return;
            if (Card.cntAnimeCards) return;
            if (!bkCards) return;
            var area = bkArea;

            var isRed = function isRed(card) {
              return card.mark < 2;
            }; //場札


            maingame.bHitAreas.forEach(function (a, i) {
              if (g.Collision.intersectAreas(bkCards[0], a)) {
                var arr = [0, -1, 1];

                for (var j = 0; j < arr.length; j++) {
                  var num_1 = i + arr[j];
                  if (num_1 < 0 || num_1 >= maingame.bAreas.length) continue;
                  var a_1 = maingame.bAreas[num_1];

                  if (!a_1.cards.length && bkCards[0].num === 13 || a_1.cards.length && a_1.cards.slice(-1)[0].num === bkCards[0].num + 1 && isRed(a_1.cards.slice(-1)[0]) !== isRed(bkCards[0])) {
                    area = a_1;
                    break;
                  }
                }
              }
            }); //組札

            if (bkCards.length === 1) {
              maingame.kHitAreas.forEach(function (a, i) {
                if (g.Collision.intersectAreas(bkCards[0], a)) {
                  var a_2 = maingame.kAreas[i];

                  if (!a_2.cards.length && bkCards[0].num === 1) {
                    area = a_2;
                    return;
                  }

                  for (var j = 0; j < maingame.kAreas.length; j++) {
                    a_2 = maingame.kAreas[j];

                    if (a_2.cards.length && a_2.cards.slice(-1)[0].num === bkCards[0].num - 1 && a_2.cards.slice(-1)[0].mark === bkCards[0].mark) {
                      area = a_2;
                      break;
                    }
                  }
                }
              });
            }

            if (area !== bkArea) {
              if (bkArea.type === 2) {
                var cards = bkArea.getCards(_this);
                area.sortCard(cards.length);
                area.setCards(cards, true, 0);
                bkArea.sortCard(0);
                bkArea.openLast();
              } else {
                var card = bkArea.getCard();
                area.sortCard(1);
                area.setCards([card], true, 0);
              }

              scene.playSound("se_move");
            } else {
              //戻す
              bkCards.forEach(function (c) {
                Card.cntAnimeCards++;
                var x = c.x - (bkCards[0].x - bkP.x);
                var y = c.y - (bkCards[0].y - bkP.y);
                timeline.create(c).moveTo(x, y, 200).call(function () {
                  Card.cntAnimeCards--;
                });
              });
              scene.playSound("se_miss");
            } //クリア判定


            maingame.clear();
          });

          return _this;
        }

        Card.cntAnimeCards = 0;
        Card.tapCard = null;
        return Card;
      }(g.E);

      exports.Card = Card;
    }, {
      "@akashic-extension/akashic-timeline": 5
    }],
    8: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.CardArea = void 0;

      var tl = require("@akashic-extension/akashic-timeline");

      var Card_1 = require("./Card"); //カードを置く場所


      var CardArea =
      /** @class */
      function (_super) {
        __extends(CardArea, _super); //this.type : 0　山札　1 手札 2 場札 3 組札


        function CardArea(x, y, type, base) {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            src: scene.asset.getImageById("card"),
            x: x,
            y: y,
            srcX: 120 * 2,
            width: 120,
            height: 180,
            parent: base
          }) || this;
          var timeline = new tl.Timeline(scene);
          _this.cards = [];
          _this.type = type;
          var bonus = [0.0, 1.0, 1.2, 1.5]; //ソートする

          _this.sortCard = function (num) {
            //手札
            if (_this.type === 1) {
              _this.cards.forEach(function (c, i) {
                c.y = _this.y;
                c.modified();
              });
            } //場札


            if (_this.type === 2) {
              var shiftNum_1 = Math.min(50, 520 / (_this.cards.length + num));

              _this.cards.forEach(function (c, i) {
                c.y = _this.y + i * shiftNum_1;
                c.modified();
              });
            }
          }; //複数枚乗せる


          _this.setCards = function (cards, isAnime, wait) {
            var num = cards.length;
            var shiftNum = Math.min(50, 520 / (_this.cards.length + num));
            cards.forEach(function (card, i) {
              var x = _this.x;
              var y = _this.y;
              if (_this.type === 2) y += (i + _this.cards.length) * shiftNum;
              if (_this.type === 1) y += i * 40;

              if (isAnime) {
                timeline.create(card).wait(wait).call(function () {
                  Card_1.Card.cntAnimeCards++;
                  base.append(card);
                }).moveTo(x, y, 200).call(function () {
                  Card_1.Card.cntAnimeCards--;
                });
              } else {
                base.append(card);
                card.x = x;
                card.y = y;
                card.modified();
              }
            });
            _this.cards = _this.cards.concat(cards);
            var card = cards[0];

            if (_this.type === 2) {
              if (!card.isBfuda) {
                scene.addScore(100 * bonus[scene.level], 300);
                card.isBfuda = true;
              }
            }

            if (_this.type === 3) {
              if (!card.isKfuda) {
                var score = 0;

                if (!card.isBfuda) {
                  score += 100;
                  card.isBfuda = true;
                }

                scene.addScore((score + card.num * 100) * bonus[scene.level], 300);
                card.isKfuda = true;
              }
            }
          }; //１枚取る


          _this.getCard = function () {
            return _this.cards.pop();
          }; //引数のカードとその上にあるカードを取得


          _this.getCards = function (card) {
            var num = _this.cards.indexOf(card);

            var c = _this.cards.slice(num);

            _this.cards = _this.cards.slice(0, num);
            return c;
          };

          _this.getCardsKeep = function (card) {
            var num = _this.cards.indexOf(card);

            var c = _this.cards.slice(num);

            return c;
          }; //全部取る


          _this.getAll = function () {
            var cs = _this.cards;
            _this.cards = [];
            return cs;
          }; //一番手前をめくる


          _this.openLast = function () {
            if (_this.cards.length && !_this.cards.slice(-1)[0].isOpen) {
              _this.cards.slice(-1)[0].open(true);

              scene.addScore(100 * bonus[scene.level], 0);
            }
          };

          return _this;
        }

        return CardArea;
      }(g.Sprite);

      exports.CardArea = CardArea;
    }, {
      "./Card": 7,
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Config = void 0;

      var Button_1 = require("./Button"); //設定画面クラス


      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 500,
            height: 700,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          }; // const events = [this.bgmEvent, this.seEvent];


          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "monospace",
            size: 48
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 48,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: "center",
            width: 500
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 60,
            width: 485,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 48,
              textColor: "black",
              x: 10,
              y: 100 + 100 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets.volume,
              width: 64,
              height: 64,
              x: 180,
              y: 100 + 100 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 260,
              y: 100 + 100 * i,
              width: 220,
              height: 64,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 26,
              width: 220,
              height: 12,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 30,
              height: 64,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.onPointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x;
              if (posX < 7) posX = 7;
              if (posX > 206) posX = 206;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.onPointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["gray", "black", "white", "green", "navy"];
          var colorNum = 0; // 背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 48,
            textColor: "black",
            x: 10,
            y: 300
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 260,
            y: 300,
            width: 220,
            height: 80,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 262,
            y: 302,
            width: 216,
            height: 76,
            cssColor: "gray",
            touchable: true
          });
          base.append(sprColor);
          sprColor.onPointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.bg) {
              _this.bg.cssColor = colors[colorNum];

              _this.bg.modified();
            }
          }); // ランキング表示

          new g.Label({
            scene: scene,
            font: font,
            text: "ランキング",
            fontSize: 48,
            textColor: "black",
            x: 10,
            y: 400,
            parent: _this
          });
          var scoreboadsNums = [3, 1, 2];

          var _loop_2 = function _loop_2(i) {
            var btnRank = new Button_1.Button(scene, [i + 1 + "枚"], 4, 456 + 80 * i, 260, 70);
            base.append(btnRank);

            btnRank.pushEvent = function () {
              if (typeof window !== "undefined" && window.RPGAtsumaru) {
                window.RPGAtsumaru.scoreboards.display(scoreboadsNums[i]);
              }
            };
          };

          for (var i = 0; i < 3; i++) {
            _loop_2(i);
          } // 閉じる


          var btnReset = new Button_1.Button(scene, ["リセット"], 276, 490, 210, 90);
          base.append(btnReset);

          btnReset.pushEvent = function () {
            scene.reset();

            _this.hide();
          }; // 閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 276, 596, 210, 90);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    10: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics5 = function extendStatics(d, b) {
          _extendStatics5 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics5(d, b);
        };

        return function (d, b) {
          _extendStatics5(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0; //import tl = require("@akashic-extension/akashic-timeline");

      var Card_1 = require("./Card");

      var CardArea_1 = require("./CardArea"); //ゲームクラス


      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            touchable: true
          }) || this; // const timeline = new tl.Timeline(scene);
          // ベース

          var base = new g.E({
            scene: scene,
            x: 0,
            width: g.game.width,
            height: g.game.height,
            parent: _this
          }); //当たり判定用前面レイヤー

          var hitBase = new g.E({
            scene: scene,
            x: 0,
            width: g.game.width,
            height: g.game.height,
            parent: _this
          });
          _this.hitBase = hitBase; // カード置き場を作る

          var createArea = function createArea(x, y, type) {
            var area = new CardArea_1.CardArea(x, y, type, base);
            return area;
          }; // 当たり判定を作る


          var createHitArea = function createHitArea(x, y, w, h) {
            var area = new g.FilledRect({
              scene: scene,
              x: x,
              y: y,
              width: w,
              height: h,
              cssColor: "yellow",
              opacity: 0.0,
              parent: hitBase
            }); //area.hide();

            return area;
          }; // 山札用の当たり判定を作成


          _this.yHitArea = createHitArea(1130, 40, 140, 200);
          _this.yHitArea.touchable = true; //手札用の当たり判定を作成

          _this.tHitArea = createHitArea(1060, 180, 10, 10); // 場札置場

          _this.bAreas = [];
          _this.bHitAreas = [];

          for (var x = 0; x < 7; x++) {
            var a = createArea(20 + x * 140, 10, 2);

            _this.bAreas.push(a);

            var ha = createHitArea(80 + x * 140, 0, 10, g.game.height);

            _this.bHitAreas.push(ha);
          } //山札・手札置き場


          var yAreas = [];

          for (var x = 0; x < 2; x++) {
            var a = createArea(1000 + x * 140, 50, 1 - x);
            yAreas.push(a);
          }

          _this.tArea = yAreas[0]; //組札置場

          _this.kAreas = [];
          _this.kHitAreas = [];

          for (var y = 0; y < 2; y++) {
            for (var x = 0; x < 2; x++) {
              var a = createArea(1000 + x * 140, 320 + y * 200, 3);

              _this.kAreas.push(a);

              var ha = createHitArea(1060 + x * 140, 400 + y * 200, 10, 10);

              _this.kHitAreas.push(ha);
            }
          } //山札作成


          var cards = [];

          for (var i = 0; i < 4; i++) {
            for (var j = 1; j <= 13; j++) {
              var card = new Card_1.Card(_this, i, j, 0, 0);
              cards.push(card);
            }
          } //山札配置


          while (cards.length > 0) {
            var num = g.game.random.get(0, cards.length - 1);
            yAreas[1].setCards([cards[num]], false, 0);
            cards.splice(num, 1);
          } //場札に配置


          var cnt = 1;

          _this.bAreas.forEach(function (area) {
            for (var i = 0; i < cnt; i++) {
              var card = yAreas[1].getCard();
              card.isBfuda = true;
              area.setCards([card], true, 0);
            }

            cnt++;
          }); //場札の先頭をめくる


          _this.bAreas.forEach(function (area) {
            area.cards.slice(-1)[0].open(true);
          }); //山札をめくる


          var next = function next() {
            if (!scene.isStart) return;

            if (yAreas[0].cards.length) {
              if (yAreas[0].cards.slice(-1)[0].x !== yAreas[0].x) {
                return;
              }
            } //山札がないときカードを山札に戻す


            if (!yAreas[1].cards.length) {
              while (yAreas[0].cards.length) {
                var card = yAreas[0].getCard();
                card.close();
                yAreas[1].setCards([card], false, 0);
              }
            } //山札から手札に移動


            var cards = [];

            for (var i = 0; i < scene.level; i++) {
              if (!yAreas[1].cards.length) break;
              var card = yAreas[1].getCard();
              cards.push(card);
              card.open(false);
            }

            yAreas[0].sortCard(0);
            yAreas[0].setCards(cards, true, 0);
          };

          _this.yHitArea.onPointDown.add(next); // 場札から組札への自動移動


          _this.autoMoves = function () {
            var cnt = 0;

            var _loop_1 = function _loop_1() {
              var flg = false;

              var areas = _this.bAreas.concat(yAreas[0]);

              areas.forEach(function (ba) {
                if (!ba.cards.length) return;
                var bc = ba.cards.slice(-1)[0];
                if (!bc.isOpen) return;

                for (var i = 0; i < _this.kAreas.length; i++) {
                  var ka = _this.kAreas[i];
                  var isMove = false;

                  if (!ka.cards.length) {
                    //組札に1枚もない
                    if (bc.num === 1) isMove = true;
                  } else {
                    var kc = ka.cards.slice(-1)[0];
                    if (bc.mark === kc.mark && bc.num - 1 === kc.num) isMove = true;
                  }

                  if (isMove) {
                    var c = ba.getCard();
                    ka.setCards([c], true, cnt * 100);
                    cnt++;
                    flg = true;
                    break;
                  }
                }
              });
              if (!flg) return "break";
            };

            while (true) {
              var state_1 = _loop_1();

              if (state_1 === "break") break;
            } //場札の一番上をめくる


            _this.bAreas.forEach(function (ba) {
              ba.openLast();
            });
          }; //クリア判定


          _this.clear = function () {
            //山札手札にカードがない
            for (var i = 0; i < yAreas.length; i++) {
              var area = yAreas[i];
              if (area.cards.length) return;
            } //場札に閉じているカードがない


            for (var i = 0; i < _this.bAreas.length; i++) {
              for (var j_1 = 0; j_1 < _this.bAreas[i].cards.length; j_1++) {
                var c = _this.bAreas[i].cards[j_1];
                if (!c.isOpen) return;
              }
            } //クリア処理


            _this.autoMoves();

            scene.addScore(Math.floor(scene.time), 300);
            scene.time = 0;
          };

          next();
          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame;
    }, {
      "./Card": 7,
      "./CardArea": 8
    }],
    11: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics6 = function extendStatics(d, b) {
          _extendStatics6 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics6(d, b);
        };

        return function (d, b) {
          _extendStatics6(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainScene = void 0;

      var tl = require("@akashic-extension/akashic-timeline");

      var Button_1 = require("./Button");

      var Config_1 = require("./Config");

      var MainGame_1 = require("./MainGame");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = _super.call(this, {
            game: g.game,
            // このシーンで利用するアセットのIDを列挙し、シーンに通知します
            assetIds: ["title", "score", "time", "start", "glyph", "number", "number_red", "config", "volume", "card", "mark", "mark2", "mark3", "number2", "cursor", "bgm", "se_start", "se_timeup", "se_move", "se_clear", "se_miss"]
          }) || this;

          _this.isStart = false;
          var timeline = new tl.Timeline(_this);
          var timeLimit = 180; // 制限時間

          var isDebug = false;
          var version = "ver. 1.05";
          _this.level = 1; // ミニゲームチャット用モードの取得と乱数シード設定

          var mode = "";

          if (typeof window !== "undefined") {
            var url = new URL(location.href);
            var seed = url.searchParams.get("date"); // eslint-disable-next-line radix

            if (seed) g.game.random = new g.XorshiftRandomGenerator(parseInt(seed));
            mode = url.searchParams.get("mode");
          } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


          g.game.vars.gameState = {
            score: 0
          };

          _this.onLoad.add(function () {
            var bgm = _this.asset.getAudioById("bgm").play();

            bgm.changeVolume(isDebug ? 0.0 : 0.2); //背景

            var bg = new g.FilledRect({
              scene: _this,
              width: g.game.width,
              height: g.game.height,
              cssColor: "green",
              parent: _this,
              opacity: param.isAtsumaru || isDebug ? 1.0 : 0.8
            });
            var base = new g.E({
              scene: _this,
              parent: _this
            });
            var maingame; // タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.asset.getImageById("title"),
              x: 0
            });

            _this.append(sprTitle);

            var font = new g.DynamicFont({
              game: g.game,
              fontFamily: "monospace",
              size: 24
            }); //バージョン情報

            new g.Label({
              scene: _this,
              font: font,
              fontSize: 24,
              text: version,
              parent: sprTitle
            });

            var _loop_1 = function _loop_1(i) {
              var area = new g.FilledRect({
                scene: _this,
                x: 576 + 208 * i,
                y: 560,
                width: 190,
                height: 112,
                cssColor: "yellow",
                opacity: 0.0,
                parent: sprTitle,
                touchable: true
              });
              area.onPointDown.add(function () {
                cursor.x = area.x;
                _this.level = i + 1;
              });
            }; //レベル変更


            for (var i = 0; i < 3; i++) {
              _loop_1(i);
            }

            var cursor = new g.Sprite({
              scene: _this,
              src: _this.asset.getImageById("cursor"),
              x: 576,
              y: 555,
              parent: sprTitle
            });
            timeline.create(sprTitle, {
              modified: sprTitle.modified
            }).wait(isDebug ? 1000 : 5000).moveBy(-1280, 0, 200).call(function () {
              init();
            }); //コンフィグ画面

            var config = new Config_1.Config(_this, 770, 10);
            config.bg = bg;
            config.hide();

            config.bgmEvent = function (num) {
              bgm.changeVolume(0.6 * num);
            };

            var init = function init() {
              // 上で生成した font.png と font_glyphs.json に対応するアセットを取得
              var fontGlyphAsset = _this.asset.getTextById("glyph"); // テキストアセット (JSON) の内容をオブジェクトに変換


              var glyphInfo = JSON.parse(fontGlyphAsset.data); // ビットマップフォントを生成

              var font = new g.BitmapFont({
                src: _this.asset.getImageById("number"),
                glyphInfo: glyphInfo
              });
              _this.font = font; // ビットマップフォントを生成

              var fontRed = new g.BitmapFont({
                src: _this.asset.getImageById("number_red"),
                glyphInfo: glyphInfo
              });
              new g.Sprite({
                scene: _this,
                src: _this.asset.getImageById("score"),
                width: 192,
                height: 64,
                x: 340,
                y: 640,
                parent: _this
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: _this,
                text: "0P",
                font: font,
                fontSize: 32,
                x: 380,
                y: 640,
                width: 450,
                widthAutoAdjust: false,
                textAlign: "right",
                parent: _this
              }); //時間の時計アイコン

              new g.Sprite({
                scene: _this,
                src: _this.asset.getImageById("time"),
                x: 5,
                y: 635,
                parent: _this
              }); // 残り時間表示用ラベル

              var timeLabel = new g.Label({
                scene: _this,
                text: "0",
                font: font,
                fontSize: 32,
                x: 105,
                y: 640,
                parent: _this
              }); //点滅用

              var sprFG = new g.FilledRect({
                scene: _this,
                width: g.game.width,
                height: g.game.height,
                cssColor: "red",
                opacity: 0
              });

              _this.append(sprFG); //スタート・終了表示用


              var stateSpr = new g.FrameSprite({
                scene: _this,
                src: _this.asset.getImageById("start"),
                width: 800,
                height: 250,
                x: (g.game.width - 800) / 2,
                y: (g.game.height - 250) / 2,
                frames: [0, 1],
                frameNumber: 0,
                parent: _this
              });

              if (param.isAtsumaru || isDebug || mode === "game") {
                //コンフィグ表示ボタン
                var btnConfig = new g.Sprite({
                  scene: _this,
                  src: _this.asset.getImageById("config"),
                  x: 1200,
                  touchable: true,
                  parent: _this
                });
                btnConfig.onPointDown.add(function () {
                  if (config.state & 1) {
                    config.show();
                  } else {
                    config.hide();
                  }
                });
              }

              var btnReset;
              var btnRanking;
              var btnExtend;

              if (param.isAtsumaru || isDebug || mode === "game") {
                // 継続ボタン
                btnExtend = new Button_1.Button(_this, ["継続"], 1000, 280, 260);
                btnExtend.modified();

                _this.append(btnExtend);

                btnExtend.pushEvent = function () {
                  _this.isStart = true;
                  stateSpr.hide();
                  sprFG.opacity = 0;
                  btnReset === null || btnReset === void 0 ? void 0 : btnReset.hide();
                  btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.hide();
                  btnExtend === null || btnExtend === void 0 ? void 0 : btnExtend.hide();
                }; // リセットボタン


                btnReset = new Button_1.Button(_this, ["リセット"], 1000, 520, 260);
                btnReset.modified();

                _this.append(btnReset);

                btnReset.pushEvent = function () {
                  _this.reset();
                }; // ランキングボタン


                btnRanking = new Button_1.Button(_this, ["ランキング"], 1000, 400, 260);
                btnRanking.modified();

                _this.append(btnRanking);

                btnRanking.pushEvent = function () {
                  //スコアを入れ直す応急措置
                  //window.RPGAtsumaru.scoreboards.setRecord(1, g.game.vars.gameState.score).then(() => {
                  //window.RPGAtsumaru.scoreboards.display(1);
                  //});
                  var scoreboadsNums = [0, 3, 1, 2];
                  window.RPGAtsumaru.scoreboards.display(scoreboadsNums[_this.level]);
                };
              }

              _this.append(config); //効果音再生


              _this.playSound = function (name) {
                _this.assets[name].play().changeVolume(config.volumes[1]);
              };

              var updateHandler = function updateHandler() {
                if (_this.time < 0) {
                  // RPGアツマール環境であればランキングを設定
                  _this.setTimeout(function () {
                    var scoreboadsNums = [0, 3, 1, 2];

                    if (param.isAtsumaru) {
                      var boardId = scoreboadsNums[_this.level];
                      var board = window.RPGAtsumaru.scoreboards;
                      board.setRecord(boardId, g.game.vars.gameState.score).then(function () {
                        btnReset === null || btnReset === void 0 ? void 0 : btnReset.show();
                        btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.show();
                        btnExtend === null || btnExtend === void 0 ? void 0 : btnExtend.show();
                      });
                    } // ミニゲームチャット用ランキング設定


                    if (mode === "game") {
                      window.parent.postMessage({
                        score: g.game.vars.gameState.score,
                        id: 1
                      }, "*");
                      btnReset.show();
                    }

                    if (isDebug) {
                      btnReset === null || btnReset === void 0 ? void 0 : btnReset.show();
                      btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.show();
                      btnExtend === null || btnExtend === void 0 ? void 0 : btnExtend.show();
                    }
                  }, 500); //終了表示


                  stateSpr.frameNumber = 1;
                  stateSpr.modified();
                  stateSpr.show();
                  _this.isStart = false;

                  _this.onUpdate.remove(updateHandler);

                  _this.playSound("se_timeup");

                  sprFG.cssColor = "black";
                  sprFG.opacity = 0.3;
                  sprFG.modified();
                } // カウントダウン処理


                _this.time -= 1 / g.game.fps;
                timeLabel.text = "" + Math.ceil(_this.time);
                timeLabel.invalidate(); //ラスト5秒の点滅

                if (_this.time <= 5) {
                  sprFG.opacity = (_this.time - Math.floor(_this.time)) / 3;
                  sprFG.modified();
                }
              }; // スコア追加


              _this.addScore = function (score, x) {
                // if (time < 0) return;
                g.game.vars.gameState.score += score;
                timeline.create(_this).every(function (e, p) {
                  scoreLabel.text = "" + (g.game.vars.gameState.score - Math.floor(score * (1 - p))) + "P";
                  scoreLabel.invalidate();
                }, 500); // スコア表示用のラベル

                var label = new g.Label({
                  scene: _this,
                  text: "+" + score,
                  font: fontRed,
                  fontSize: 32,
                  x: x,
                  y: 580,
                  width: 410,
                  widthAutoAdjust: false,
                  textAlign: "right",
                  opacity: 0.0,
                  parent: _this
                });
                timeline.create(label).every(function (e, p) {
                  label.opacity = p;
                }, 100).wait(500).call(function () {
                  label.destroy();
                });
              }; //リセット処理


              _this.reset = function () {
                _this.isStart = true;
                maingame === null || maingame === void 0 ? void 0 : maingame.destroy();
                maingame = new MainGame_1.MainGame();
                base.append(maingame);
                _this.time = timeLimit;
                timeLabel.text = "" + _this.time;
                timeLabel.invalidate();
                g.game.vars.gameState.score = 0;
                scoreLabel.text = "0";
                scoreLabel.invalidate();
                stateSpr.frameNumber = 0;
                stateSpr.modified();
                stateSpr.show();

                _this.setTimeout(function () {
                  stateSpr.hide();
                }, 1000);

                btnExtend === null || btnExtend === void 0 ? void 0 : btnExtend.hide();
                btnReset === null || btnReset === void 0 ? void 0 : btnReset.hide();
                btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.hide();

                _this.playSound("se_start");

                sprFG.opacity = 0;
                sprFG.cssColor = "red";
                sprFG.modified();

                _this.onUpdate.remove(updateHandler);

                _this.onUpdate.add(updateHandler);
              };

              _this.reset();
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "./Button": 6,
      "./Config": 9,
      "./MainGame": 10,
      "@akashic-extension/akashic-timeline": 5
    }],
    12: [function (require, module, exports) {
      // 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器
        // param.random = g.game.random;

        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              g.game.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 13
    }],
    13: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      var MainScene_1 = require("./MainScene");

      function main(param) {
        var scene = new MainScene_1.MainScene(param);
        g.game.pushScene(scene);
      }

      exports.main = main;
    }, {
      "./MainScene": 11
    }]
  }, {}, [12])(12);
});